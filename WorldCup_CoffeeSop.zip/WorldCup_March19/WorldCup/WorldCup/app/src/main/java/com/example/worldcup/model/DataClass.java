package com.example.worldcup.model;

import java.io.Serializable;

public class DataClass implements Serializable {
    private String imageUrl;

    public DataClass(){
    }

    public DataClass(String imageURL) {
        this.imageUrl = imageURL;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }


}
