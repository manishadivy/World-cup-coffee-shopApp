package com.example.worldcup;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.worldcup.model.Catalog;
import com.example.worldcup.model.CatalogAdapter;
import com.example.worldcup.model.FileManagement;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;

public class CatalogActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener, View.OnClickListener, DialogInterface.OnClickListener {

    ListView lvUserCatalog;
    ArrayList<Catalog> catalogList;
    CatalogAdapter catalogAdapter;
    TextView tvWelcome, tvSubmit, tvTotal;
    private Spinner spinner;
    AlertDialog.Builder confirmLogOut, confirmOrder, ThankYou, noOrder;
    private double grandTotal = 0.0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_catalog);
        initialize();
    }

    private void initialize() {
        tvSubmit = findViewById(R.id.tvSubmit);
        tvSubmit.setOnClickListener(this);
        tvTotal = findViewById(R.id.tvTotal);
        tvTotal.setText("$0.00");
        tvWelcome = findViewById(R.id.tvWelcome);
        Date currentTime = Calendar.getInstance().getTime();
        String formattedDate = DateFormat.getDateInstance().format(currentTime);
        tvWelcome.setText(formattedDate);

        lvUserCatalog = findViewById(R.id.lvUserCatalog);
        catalogList = FileManagement.readFile(this, "catalog.txt");
        catalogAdapter = new CatalogAdapter(this, catalogList, this);
        lvUserCatalog.setAdapter(catalogAdapter);

        resetSpinner();

        ThankYou = new AlertDialog.Builder(this);
    }

    public void addTotal(double total) {
        grandTotal += total;
        tvTotal.setText(String.format("$%.2f", grandTotal));
    }

    public void subtractTotal(double total) {
        grandTotal -= total;
        tvTotal.setText(String.format("$%.2f", grandTotal));
    }


    private void resetSpinner() {
        spinner = findViewById(R.id.spinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.menuCatalog, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this);
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int i, long id) {
        String choice = parent.getItemAtPosition(i).toString();
        //Toast.makeText(getApplicationContext(), choice, Toast.LENGTH_LONG).show();

        if (choice.equalsIgnoreCase("Home")) {
            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(intent);
            finish();
        }
        if (choice.equalsIgnoreCase("Trolley")) {
            resetSpinner();
//            Intent intent = new Intent(getApplicationContext(), TrolleyActivity.class);
//            startActivity(intent);
//            finish();
        }
        if (choice.equalsIgnoreCase("My Account")) {
            Intent intent = new Intent(getApplicationContext(), MyAccountActivity.class);
            startActivity(intent);
            finish();
        }
        if (choice.equalsIgnoreCase("Log Out")) {
            confirmLogOut = new AlertDialog.Builder(this);
            confirmLogOut.setTitle("Log Out");
            confirmLogOut.setMessage("Do you want to log out (YES/NO)");
            confirmLogOut.setPositiveButton("YES", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    FirebaseAuth.getInstance().signOut();
                    Intent intent = new Intent(CatalogActivity.this, LoginActivity.class);
                    startActivity(intent);
                    finish();
                }
            });
            confirmLogOut.setNegativeButton("NO", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    resetSpinner();
                }
            });
            confirmLogOut.create().show();
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    @Override
    public void onClick(View view) {
        int id = view.getId();
        switch (id) {
            case R.id.tvSubmit:

                if (grandTotal != 0.0) {
                    confirmOrder = new AlertDialog.Builder(this);
                    confirmOrder.setTitle("Confirm Order");
                    confirmOrder.setMessage(Html.fromHtml(String.format("Your order will be sent to WorldCup Coffee Shop for a total of <font color='red'><b>$%.2f</b></font>.<br>Do you confirm?", grandTotal)));
                    confirmOrder.setPositiveButton("YES", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            ThankYou.setTitle("Thank you");
                            ThankYou.setMessage(Html.fromHtml("Thank you for your order.\nIt will be ready for pick up in <u>20 minutes!</u>"));
                            ThankYou.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    Intent intent = new Intent(CatalogActivity.this, MainActivity.class);
                                    startActivity(intent);
                                    finish();
                                }
                            });
                            ThankYou.create().show();
                        }
                    });
                    confirmOrder.setNegativeButton("NO", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            resetSpinner();
                        }
                    });
                    confirmOrder.create().show();
                    break;
                } else {
                    noOrder = new AlertDialog.Builder(this);
                    noOrder.setTitle("Error");
                    noOrder.setMessage("There is no order to submit!");
                    noOrder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            resetSpinner();
                        }
                    });
                    noOrder.create().show();
                }
        }
    }

    @Override
    public void onClick(DialogInterface dialog, int which) {

    }

}
