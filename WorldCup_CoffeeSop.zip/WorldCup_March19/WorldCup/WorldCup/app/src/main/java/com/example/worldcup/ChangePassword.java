package com.example.worldcup;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.text.DateFormat;
import java.util.Calendar;
import java.util.Date;

public class ChangePassword extends AppCompatActivity implements OnCompleteListener{
    TextView tvWelcome, tvHome;
    EditText  edNewPassword, edConfirmPassword;
    AlertDialog.Builder passwordChanged, errorMessage;
    Button btnUpdatePassword;
    FirebaseAuth auth;
    FirebaseUser user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_password);
        initialize();
    }

    private void initialize() {
        tvWelcome = findViewById(R.id.tvWelcome);
        Date currentTime = Calendar.getInstance().getTime();
        String formattedDate = DateFormat.getDateInstance().format(currentTime);
        tvWelcome.setText(formattedDate);

        tvHome = findViewById(R.id.tvHome);
        tvHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
                finish();
            }
        });

        edNewPassword = findViewById(R.id.edNewPassword);
        edConfirmPassword = findViewById(R.id.edConfirmPassword);

        auth = FirebaseAuth.getInstance();
        user = auth.getCurrentUser();

        btnUpdatePassword = findViewById(R.id.btnUpdatePassword);
        btnUpdatePassword.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 String newPassword = edNewPassword.getText().toString();
                 String confirmPassword = edConfirmPassword.getText().toString();
                 if (confirmPassword.equals(newPassword) && newPassword.length() > 5) {
                     user.updatePassword(newPassword);
                     passwordChanged = new AlertDialog.Builder(ChangePassword.this);
                     passwordChanged.setTitle("Confirmation");
                     passwordChanged.setMessage("New password is registered.");
                     passwordChanged.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                         @Override
                         public void onClick(DialogInterface dialog, int which) {
                             edNewPassword.setText(null);
                             edConfirmPassword.setText(null);
                             Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                             startActivity(intent);
                             finish();
                         }
                     });
                     passwordChanged.create().show();
                    }
                 else {
                     errorMessage = new AlertDialog.Builder(ChangePassword.this);
                     errorMessage.setTitle("Error");
                     errorMessage.setMessage("New Email does not match field Confirm Email or Password is less than 6 characters");
                     errorMessage.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                         @Override
                         public void onClick(DialogInterface dialog, int which) {
                             edNewPassword.setText(null);
                             edConfirmPassword.setText(null);
                         }
                     });
                     errorMessage.create().show();
                 }
             }
         });
    }

    @Override
    public void onComplete(@NonNull Task task) {
    }


}
