package com.example.worldcup;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ViewFlipper;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.text.DateFormat;
import java.util.Calendar;
import java.util.Date;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener, View.OnClickListener, DialogInterface.OnClickListener {

    private Spinner spinner;
    ViewFlipper flipper ;
    FirebaseAuth auth;
    TextView tvUserName, tvBecomeMember , tvMoreTriviaInquiry, tvMoreFeaturedStory, tvFeedback;
    FirebaseUser user;
    AlertDialog.Builder confirmLogOut;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initialize();
    }

    private void resetSpinner() {
        spinner = findViewById(R.id.spinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.menuHome, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this);
    }

    private void initialize() {
        resetSpinner();

        confirmLogOut = new AlertDialog.Builder(this);
        confirmLogOut.setTitle("Log Out");
        confirmLogOut.setMessage("Do you want to log out (YES/NO)");
        confirmLogOut.setPositiveButton("YES", this);
        confirmLogOut.setNegativeButton("NO", this);

        auth = FirebaseAuth.getInstance();
        tvUserName = findViewById(R.id.tvUserName);
        user = auth.getCurrentUser();
        Date currentTime = Calendar.getInstance().getTime();
        String formattedDate = DateFormat.getDateInstance().format(currentTime);
        if(user == null){
            Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
            startActivity(intent);
            finish();
        }
        else{
            tvUserName.setText("Welcome!" + "  " + formattedDate);
        }

        //FEATURED STORY
        tvMoreFeaturedStory = findViewById(R.id.tvMoreFeaturedStory);
        String textStory = "More...";
        SpannableString SpannableString2 = new SpannableString(textStory);
        ClickableSpan ClickableSpan2 = new ClickableSpan() {
            @Override
            public void onClick(View widget) {
                Intent intent = new Intent(getApplicationContext(), FeaturedStory.class);
                startActivity(intent);
                finish();
            }
        };
        SpannableString2.setSpan(ClickableSpan2,0,7, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        tvMoreFeaturedStory.setText( SpannableString2);
        tvMoreFeaturedStory.setMovementMethod(LinkMovementMethod.getInstance());

        //IMAGE SLIDER
        int imgarray[] ={R.drawable.images1,R.drawable.images2,R.drawable.images3,R.drawable.images4,R.drawable.images5,R.drawable.images6};
        flipper = findViewById(R.id.flipper);
        for(int i=0; i< imgarray.length; i++){
            showImage(imgarray[i]);
        }

        //TRIVIA
        tvMoreTriviaInquiry = findViewById(R.id.tvMoreTriviaInquiry);
        String textInquiryTrivia = "More...";
        SpannableString SpannableString1 = new SpannableString(textInquiryTrivia);
        ClickableSpan ClickableSpan1 = new ClickableSpan() {
            @Override
            public void onClick(View widget) {
                Intent intent = new Intent(getApplicationContext(), TriviaPage.class);
                startActivity(intent);
                finish();
            }
        };
        SpannableString1.setSpan(ClickableSpan1,0,7, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        tvMoreTriviaInquiry.setText( SpannableString1);
        tvMoreTriviaInquiry.setMovementMethod(LinkMovementMethod.getInstance());

        tvBecomeMember = findViewById(R.id.tvBecomeMember);
        tvBecomeMember.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), BecomeMemberPage.class);
                startActivity(intent);
                finish();
            }
        });

        tvFeedback = findViewById(R.id.tvFeedback);
        tvFeedback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), FeedBackActivity.class);
                startActivity(intent);
                finish();
            }
        });

    }

    private void showImage(int img) {
        ImageView imageView = new ImageView(this);
        imageView.setBackgroundResource(img);
        flipper.addView(imageView);
        flipper.setFlipInterval(3000);
        flipper.setAutoStart(true);
        flipper.setInAnimation(this, android.R.anim.slide_in_left);
        flipper.setOutAnimation(this, android.R.anim.slide_out_right);
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long id) {
        String choice = adapterView.getItemAtPosition(i).toString();

        if(choice.equalsIgnoreCase("Catalog"))
        {
            Intent intent = new Intent(getApplicationContext(), CatalogActivity.class);
            startActivity(intent);
            finish();
        }
        if(choice.equalsIgnoreCase("Trolley"))
        {
            resetSpinner();
//            Intent intent = new Intent(getApplicationContext(), TrolleyActivity.class);
//            startActivity(intent);
//            finish();
        }
        if(choice.equalsIgnoreCase("My Account"))
        {
            Intent intent = new Intent(getApplicationContext(), MyAccountActivity.class);
            startActivity(intent);
            finish();
        }
        if(choice.equalsIgnoreCase("Log Out"))
        {
            confirmLogOut.create().show();
        }

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    @Override
    public void onClick(View view) {
//        int Id = view.getId();
//        switch(Id){
//            case R.id.tvAd:
//                //Intent intent = new Intent(this, MembershipActivity.class);
//                //startActivity(intent);
//        }
    }

    @Override
    public void onClick(DialogInterface dialog, int which) {
        switch(which){
            case Dialog.BUTTON_POSITIVE:
                FirebaseAuth.getInstance().signOut();
                Intent intent = new Intent(this, LoginActivity.class);
                startActivity(intent);
                finish();
                break;
            case Dialog.BUTTON_NEGATIVE:
                resetSpinner();
                break;
        }
    }
}