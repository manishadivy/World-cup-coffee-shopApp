package com.example.worldcup.model;

import androidx.annotation.NonNull;

import java.io.Serializable;

public class User implements Serializable {
    private String firstName, lastName, email, phone;
    CreditCard creditCard;


    public User() {
    }

    public User(String firstName, String lastName, String email, String phone, CreditCard creditCard) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.phone = phone;
        this.creditCard = creditCard;
    }


    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public CreditCard getCreditCard() {
        return creditCard;
    }

    public void setCreditCard(CreditCard creditCard) {
        this.creditCard = creditCard;
    }

    @NonNull
    @Override
    public String toString() {
        return super.toString();
    }
}
