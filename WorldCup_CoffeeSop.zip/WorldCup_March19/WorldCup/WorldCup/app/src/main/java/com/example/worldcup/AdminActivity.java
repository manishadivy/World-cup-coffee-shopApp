package com.example.worldcup;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.firebase.auth.FirebaseAuth;

public class AdminActivity extends AppCompatActivity implements View.OnClickListener, DialogInterface.OnClickListener {

    Button btnCatalog, btnFeaturedStory, btnTrivia, btnLogOut;
    AlertDialog.Builder confirmLogOut;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);
        initialize();
    }

    private void initialize() {
        btnCatalog = findViewById(R.id.btnCatalog);
        btnFeaturedStory = findViewById(R.id.btnFeaturedStory);
        btnTrivia = findViewById(R.id.btnTrivia);
        btnLogOut = findViewById(R.id.btnLogOut);
        btnCatalog.setOnClickListener(this);
        btnFeaturedStory.setOnClickListener(this);
        btnTrivia.setOnClickListener(this);
        btnLogOut.setOnClickListener(this);

        confirmLogOut = new AlertDialog.Builder(this);
        confirmLogOut.setTitle("Log Out");
        confirmLogOut.setMessage("Do you want to log out (YES/NO)");
        confirmLogOut.setPositiveButton("YES", this);
        confirmLogOut.setNegativeButton("NO", this);
    }

    @Override
    public void onClick(View view) {
        int id = view.getId();
        switch(id){
            case R.id.btnCatalog:
                Intent i = new Intent(this, CrudCatalogActivity.class);
                startActivity(i);
                break;
            case R.id.btnFeaturedStory:
//                Intent i = new Intent(this, CrudFeaturedStoryActivity.class);
//                startActivity(i);
                break;
            case R.id.btnTrivia:
//                Intent i = new Intent(this, CrudTriviaActivity.class);
//                startActivity(i);
                break;
            case R.id.btnLogOut:
                confirmLogOut.create().show();
                break;
        }
    }

    @Override
    public void onClick(DialogInterface dialog, int which) {
        switch(which){
            case Dialog.BUTTON_POSITIVE:
                FirebaseAuth.getInstance().signOut();
                Intent intent = new Intent(this, LoginActivity.class);
                startActivity(intent);
                break;
            case Dialog.BUTTON_NEGATIVE:
                break;
        }
    }
}