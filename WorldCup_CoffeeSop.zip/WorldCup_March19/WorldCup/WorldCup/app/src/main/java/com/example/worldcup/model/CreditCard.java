package com.example.worldcup.model;

import java.io.Serializable;
import java.nio.file.SecureDirectoryStream;

public class CreditCard implements Serializable
{
    String number;
    int year, month;
    String CVV;

    public CreditCard() {
    }

    public CreditCard(String number, int year, int month, String CCV) {
        this.number = number;
        this.year = year;
        this.month = month;
        this.CVV = CCV;
    }

    public String getNumber() {
        return number;

    }

    public void setNumber(String number) {
        this.number = number;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getMonth() {
        return month;
    }

    public void setMonth(int month) {
        this.month = month;
    }

    public String getCCV() {
        return CVV;
    }

    public void setCCV(String CCV) {
        this.CVV = CCV;
    }
}
