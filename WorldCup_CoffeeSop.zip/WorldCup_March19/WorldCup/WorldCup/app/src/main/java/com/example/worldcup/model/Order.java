package com.example.worldcup.model;

import androidx.annotation.NonNull;

import java.util.Date;

public class Order {
    private String title;
    private Date date;
    private int quantity;
    private float price;

    public Order() {
    }

    public Order(String title, Date date, int quantity, float price) {
        this.title = title;
        this.date = date;
        this.quantity = quantity;
        this.price = price;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    @NonNull
    @Override
    public String toString() {
        return super.toString();
    }

    public double getTotalPrice(int quantity, float price){
        double totalPrice;
        totalPrice = (quantity * price) + (price * 0.15);
        return totalPrice;

    }
}
