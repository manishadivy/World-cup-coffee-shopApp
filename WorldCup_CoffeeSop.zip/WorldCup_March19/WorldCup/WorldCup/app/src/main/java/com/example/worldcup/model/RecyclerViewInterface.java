package com.example.worldcup.model;

public interface RecyclerViewInterface {
    void onItemClick(int position);
}
