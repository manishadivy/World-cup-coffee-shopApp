package com.example.worldcup.model;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.bumptech.glide.Glide;
import com.example.worldcup.CatalogActivity;
import com.example.worldcup.CrudCatalogActivity;
import com.example.worldcup.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import org.w3c.dom.Text;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class CatalogAdapter extends BaseAdapter
{
    private final int[] orderedQuantities;
    private Context context;
    private ArrayList<Catalog> catalogList;
    private int[] counters;
    Catalog catalog;
    TextView tvTotal;
    double grandTotal;
    CatalogActivity activity;



    public CatalogAdapter(Context context, ArrayList<Catalog> catalogList, CatalogActivity activity) {
        this.context = context;
        this.catalogList = catalogList;
        this.activity = activity;
        counters = new int[catalogList.size()];
        grandTotal = 0.0;
        this.orderedQuantities = new int[catalogList.size()];
        Arrays.fill(orderedQuantities, 0);

    }

    @Override
    public int getCount() {
        return catalogList.size();
    }

    @Override
    public Object getItem(int position) {
        return  catalogList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup viewGroup)
    {
        View userCatalogItem = null;
        ImageView imPhoto, imLess, imMore;
        TextView tvTitle, tvCountry, tvDescription, tvPrice, tvCounter, tvTotal;

        LayoutInflater inflater = LayoutInflater.from(context);
        userCatalogItem = inflater.inflate(R.layout.user_catalog_item, viewGroup, false);

        tvTitle = userCatalogItem.findViewById(R.id.tvTitle);
        tvCountry = userCatalogItem.findViewById(R.id.tvCountry);
        tvDescription = userCatalogItem.findViewById(R.id.tvDescription);
        tvPrice = userCatalogItem.findViewById(R.id.tvPrice);
        tvCounter = userCatalogItem.findViewById(R.id.tvCounter);

        imPhoto = userCatalogItem.findViewById(R.id.imPhoto);
        imLess = userCatalogItem.findViewById(R.id.imLess);
        imMore = userCatalogItem.findViewById(R.id.imMore);

        catalog = catalogList.get(position);

        tvTitle.setText(catalog.getTitle());
        tvCountry.setText(catalog.getCountry());
        tvDescription.setText(catalog.getDescription());
        tvPrice.setText(String.valueOf(catalog.getPrice()));

        String strPhoto =  catalog.getPhoto();
        Picasso.with(context).load(strPhoto).placeholder(R.drawable.temp_image).into(imPhoto);

        tvCounter.setText(String.valueOf(catalog.getCounter()));

        imMore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                orderedQuantities[position]++;
                counters[position]++;
                catalog.setCounter(counters[position]); // update the catalog object's counter field
                tvCounter.setText(String.valueOf(counters[position]));
                double total = catalogList.get(position).getPrice();
                ((CatalogActivity) context).addTotal(total);
            }
        });

        imLess.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (counters[position] > 0) {
                    orderedQuantities[position]--;
                    counters[position]--;
                    catalog.setCounter(counters[position]); // update the catalog object's counter field
                    tvCounter.setText(String.valueOf(counters[position]));
                    double total = catalogList.get(position).getPrice();
                    ((CatalogActivity) context).subtractTotal(total);
                }
            }
        });

        return userCatalogItem;
    }
}
