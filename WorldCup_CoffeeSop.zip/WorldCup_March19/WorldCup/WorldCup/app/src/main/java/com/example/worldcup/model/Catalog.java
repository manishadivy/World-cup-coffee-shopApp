package com.example.worldcup.model;

import androidx.annotation.NonNull;

public class Catalog {
    private int id, quantity;
    private String photo, title, description, country;
    private float price;
    private int counter;

    public Catalog() {
    }

    public Catalog(int id, String photo, String title, String description, String country, float price, int quantity) {
        this.id = id;
        this.photo = photo;
        this.title = title;
        this.description = description;
        this.country = country;
        this.price = price;
        this.quantity = quantity;
        this.counter = 0;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public int getCounter() {
        return counter;
    }

    public void setCounter(int counter) {
        this.counter = counter;
    }

    @NonNull
    @Override
    public String toString() {
        return  photo + title + description + country + price + quantity;
    }

//    public void incrementCounter() {
//        this.counter++;
//    }
//
//    public void decrementCounter() {
//        this.counter--;
//    }
}
