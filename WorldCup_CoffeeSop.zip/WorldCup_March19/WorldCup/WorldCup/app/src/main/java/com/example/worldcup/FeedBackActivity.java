package com.example.worldcup;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.worldcup.model.Feedback;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.DateFormat;
import java.util.Calendar;
import java.util.Date;

public class FeedBackActivity extends AppCompatActivity implements View.OnClickListener {

    TextView tvFeedback, tvWelcome, tvBack;;
    RatingBar rbStars;
    EditText edFeedback;
    Button btnSend;
    DatabaseReference worldcupDatabase;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feed_back);

        tvWelcome = findViewById(R.id.tvWelcome);
        Date currentTime = Calendar.getInstance().getTime();
        String formattedDate = DateFormat.getDateInstance().format(currentTime);
        tvWelcome.setText(formattedDate);

        tvBack = findViewById(R.id.tvBack);
        tvBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
                finish();
            }
        });

        tvFeedback = findViewById(R.id.tvFeedback);
        rbStars = findViewById(R.id.rbStars);
        edFeedback = findViewById(R.id.edFeedback);
        btnSend = findViewById(R.id.btnSend);
        btnSend.setOnClickListener(this);

        worldcupDatabase = FirebaseDatabase
                .getInstance()
                .getReference("feedback");

        rbStars.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                if (rating == 1 || rating == 0.5) {
                    tvFeedback.setText("Not happy");
                    edFeedback.setText("My coffee was cold!");

                } else if (rating == 2 || rating == 2.5 || rating == 1.5) {
                    tvFeedback.setText("ok");
                    edFeedback.setText(" The experience had some drawbacks or issues that prevented it from being fully enjoyable.");
                } else if (rating == 3 || rating == 3.5) {
                    tvFeedback.setText("Satisfied");
                    edFeedback.setText("The experience was generally positive, with some standout aspects that made it enjoyable ");
                } else if (rating == 4) {
                    tvFeedback.setText(" Very Satisfied");
                    edFeedback.setText(" The coffee was decent, the service was adequate, and the atmosphere was pleasant!");
                } else if (rating == 4.5 || rating == 5) {
                    tvFeedback.setText("Excellent Service");
                    edFeedback.setText("Very Satisfying Service !");
                    edFeedback.setText("The coffee was excellent, employees were attentive, and the atmosphere was to die for!");
                } else {  }
            }
        });
    }

    @Override
    public void onClick(View view) {
        int id = view.getId();
        switch (id) {
            case R.id.btnSend:
                float rating = Float.parseFloat(String.valueOf(rbStars.getNumStars()));
                String comment = edFeedback.getText().toString();
                Feedback feedback = new Feedback(rating, comment);
                String feedbackId = worldcupDatabase.push().getKey();
                worldcupDatabase.child(feedbackId).setValue(feedback);
                Toast.makeText(this, "Feedback sent successfully", Toast.LENGTH_SHORT).show();
        }
    }
}