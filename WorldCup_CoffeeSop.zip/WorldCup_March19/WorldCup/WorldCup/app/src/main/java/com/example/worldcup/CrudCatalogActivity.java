package com.example.worldcup;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.worldcup.model.Catalog;
import com.example.worldcup.model.DataClass;
import com.example.worldcup.model.Order;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class CrudCatalogActivity extends AppCompatActivity implements View.OnClickListener, OnSuccessListener, OnFailureListener, OnCompleteListener, AdapterView.OnItemClickListener, ChildEventListener {
    EditText edId, edTitle, edDescription, edCountry, edQuantity, edPrice;
    static ImageView imCatalog;
    Button btnAdd, btnUpdate, btnFind, btnBack;
    ListView lvCatalog;
    List<String> catalogItems;
    DatabaseReference catalogDatabase;
    FirebaseStorage storage;
    StorageReference storageReference, sRef;
    ActivityResultLauncher actResLauncher;
    Uri filePath;
    ProgressDialog prDialog;
    String photoPath = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crud_catalog);
        initialize();
    }

    private void initialize() {
        edId = findViewById(R.id.edId);
        edTitle = findViewById(R.id.edTitle);
        edDescription = findViewById(R.id.edDescription);
        edCountry = findViewById(R.id.edCountry);
        edQuantity = findViewById(R.id.edQuantity);
        edPrice = findViewById(R.id.edPrice);

        lvCatalog = findViewById(R.id.lvCatalog);
        lvCatalog.setOnItemClickListener(this);

        btnAdd = findViewById(R.id.btnAdd);
        btnUpdate = findViewById(R.id.btnUpdate);
        btnFind = findViewById(R.id.btnFind);
        btnBack = findViewById(R.id.btnBack);

        btnAdd.setOnClickListener(this);
        btnUpdate.setOnClickListener(this);
        btnFind.setOnClickListener(this);
        btnBack.setOnClickListener(this);

        imCatalog = findViewById(R.id.imCatalog);
        imCatalog.setOnClickListener(this);

        catalogDatabase = FirebaseDatabase
                .getInstance()
                .getReference("catalog");

        catalogDatabase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                catalogItems = new ArrayList<>();
                for (DataSnapshot itemSnapshot : snapshot.getChildren()) {
                    int id = Integer.parseInt(itemSnapshot.child("id").getValue().toString());
                    String title = itemSnapshot.child("title").getValue(String.class);
                    String country = itemSnapshot.child("country").getValue(String.class);
                    String desc = itemSnapshot.child("description").getValue(String.class);
                    int quantity = Integer.parseInt(itemSnapshot.child("quantity").getValue().toString());
                    float price = Float.parseFloat(itemSnapshot.child("price").getValue().toString());
                    String photo = itemSnapshot.child("photo").getValue(String.class);
                    catalogItems.add(id + " - " + title + " - " + country + " - " + quantity + " - " + price);
                }
                ArrayAdapter<String> adapter = new ArrayAdapter<>(CrudCatalogActivity.this, android.R.layout.simple_list_item_1, catalogItems);
                lvCatalog.setAdapter(adapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        storage = FirebaseStorage.getInstance();
        storageReference = storage.getReference();
        registerActResLauncher();

    }

    private void registerActResLauncher() {
        actResLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        getPhoto(result);
                    }
                }
        );
    }

    private void getPhoto(ActivityResult result) {
        if (result.getResultCode() == Activity.RESULT_OK) {
            Intent data = result.getData();
            if (data != null) {
                String selectedImageUrl = data.getStringExtra("selected_image_url");

                Glide.with(this).load(selectedImageUrl).placeholder(R.drawable.temp_image).into(imCatalog);
            }
        }
    }



    @Override
    public void onClick(View view) {
        int id = view.getId();
        switch (id) {
            case R.id.btnAdd:
                addItem();
                break;
            case R.id.btnUpdate:
                updateItem();
                break;
            case R.id.btnBack:
                finish();
                break;
            case R.id.btnFind:
                findItem();
                break;
            case R.id.imCatalog:
                selectPhoto();
                break;
        }
    }

    private void selectPhoto() {
        Intent intent = new Intent(this, SelectPhotoActivity.class);
        actResLauncher.launch(intent);
    }

    private void addItem() {
        uploadPhoto();
        photoPath = imCatalog.toString();
        addItemInfo();
    }

    private void uploadPhoto() {

        if (filePath != null) {
            prDialog = new ProgressDialog(this);
            prDialog.setTitle("Uploading photo...");
            prDialog.show();
            sRef = storageReference.child("images_catalog/" + UUID.randomUUID());
            sRef.putFile(filePath).addOnSuccessListener(this).addOnFailureListener(this);
        }
    }

    private void updateItem() {
        uploadPhoto();
        photoPath = imCatalog.toString();
        addItemInfo();
    }

    private void findItem() {
        String id = edId.getText().toString();
        DatabaseReference catalogChild;
        catalogChild = catalogDatabase.child(id);
        catalogChild.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                try {
                    if (snapshot.exists()) {
                        String title = snapshot.child("title").getValue().toString();
                        edTitle.setText(title);
                        String desc = snapshot.child("description").getValue().toString();
                        edDescription.setText(desc);
                        String country = snapshot.child("country").getValue().toString();
                        edCountry.setText(country);
                        int quantity = Integer.parseInt(snapshot.child("quantity").getValue().toString());
                        edQuantity.setText(Integer.toString(quantity));
                        float price = Float.parseFloat(snapshot.child("price").getValue().toString());
                        edPrice.setText(Float.toString(price));

                        String urlPhoto = snapshot.child("photo").getValue().toString();
                        Glide.with(CrudCatalogActivity.this).load(urlPhoto).placeholder(R.drawable.temp_image).into(imCatalog);
                    } else{
                        Toast.makeText(CrudCatalogActivity.this, "No item found!", Toast.LENGTH_SHORT).show();
                        clearWidgets();
                    }
                } catch (Exception ex) {
                    Toast.makeText(CrudCatalogActivity.this, ex.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(CrudCatalogActivity.this, error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onComplete(@NonNull Task task) {
        Toast.makeText(this, "ONCOMPLETE executing", Toast.LENGTH_LONG).show();
        photoPath = task.getResult().toString();
        Toast.makeText(this, photoPath, Toast.LENGTH_LONG).show();
    }

    private void clearWidgets(){
        edId.setText(null);
        edTitle.setText(null);
        edDescription.setText(null);
        edCountry.setText(null);
        edQuantity.setText(null);
        edPrice.setText(null);
        imCatalog.setImageBitmap(null);
    }

    private void addItemInfo() {
        if (photoPath != null ) {
            int id = Integer.parseInt(edId.getText().toString());
            String title = edTitle.getText().toString();
            String description = edDescription.getText().toString();
            String country = edCountry.getText().toString();
            int quantity = Integer.parseInt(edQuantity.getText().toString());
            float price = Float.parseFloat(edPrice.getText().toString());

            Catalog item = new Catalog(id, photoPath, title, description, country, price, quantity);

            catalogDatabase.child(edId.getText().toString()).setValue(item);
            Toast.makeText(this, "The item " + title + "has been added successfully", Toast.LENGTH_SHORT).show();
            photoPath = null;
            clearWidgets();
        }

    }

    @Override
    public void onFailure(@NonNull Exception e) {
        Toast.makeText(this, "Error", Toast.LENGTH_LONG).show();
        prDialog.dismiss();
    }

    @Override
    public void onSuccess(Object o) {
        Toast.makeText(this, "A new item has been uploaded successfully", Toast.LENGTH_LONG).show();
        sRef.getDownloadUrl().addOnCompleteListener(this);
        prDialog.dismiss();
    }


    @Override
    public void onItemClick(AdapterView<?> parent, View view, int i, long l) {
        String selectedItem = (String) parent.getItemAtPosition(i);
        String[] parts = selectedItem.split(" - ");
        int id = Integer.parseInt(parts[0]);
        DatabaseReference catalogChild;
        catalogChild = catalogDatabase.child(String.valueOf(id));
        catalogChild.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                try {
                    if (snapshot.exists()) {
                        int id = Integer.parseInt(snapshot.child("id").getValue().toString());
                        edId.setText(Integer.toString(id));
                        String title = snapshot.child("title").getValue().toString();
                        edTitle.setText(title);
                        String desc = snapshot.child("description").getValue().toString();
                        edDescription.setText(desc);
                        String country = snapshot.child("country").getValue().toString();
                        edCountry.setText(country);
                        int quantity = Integer.parseInt(snapshot.child("quantity").getValue().toString());
                        edQuantity.setText(Integer.toString(quantity));
                        float price = Float.parseFloat(snapshot.child("price").getValue().toString());
                        edPrice.setText(Float.toString(price));
                        String urlPhoto = snapshot.child("photo").getValue().toString();
                        Glide.with(CrudCatalogActivity.this).load(urlPhoto).placeholder(R.drawable.temp_image).into(imCatalog);
                    } else {
                        Toast.makeText(CrudCatalogActivity.this, "No item found!", Toast.LENGTH_SHORT).show();
                        clearWidgets();
                    }
                } catch (Exception ex) {
                    Toast.makeText(CrudCatalogActivity.this, ex.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(CrudCatalogActivity.this, error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

}

    @Override
    public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
        Catalog item = snapshot.getValue(Catalog.class);
        Toast.makeText(this, item.toString(), Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

    }

    @Override
    public void onChildRemoved(@NonNull DataSnapshot snapshot) {

    }

    @Override
    public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

    }

    @Override
    public void onCancelled(@NonNull DatabaseError error) {
        Toast.makeText(this, error.getMessage(), Toast.LENGTH_SHORT).show();
    }
}