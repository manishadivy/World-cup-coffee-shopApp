package com.example.worldcup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.worldcup.model.CreditCard;
import com.example.worldcup.model.User;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.ktx.Firebase;

import java.text.DateFormat;
import java.time.YearMonth;
import java.util.Calendar;
import java.util.Date;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MyAccountActivity extends AppCompatActivity implements DialogInterface.OnClickListener {

    TextView tvWelcome, tvBack;
    EditText edProfileFirstName, edProfileLastName, edProfileEmail, edProfilePhone, edProfileCreditCard, edCCYear, edCCMonth, edCVV;
    Button btnUpdateProfile, btnChangePassword;
    AlertDialog.Builder fieldsRequired, creditCardLength, creditCardYearMonth, creditCardCVV, verifyPhone, thankYou;
    DatabaseReference userDatabase;
    FirebaseAuth auth;
    FirebaseUser user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_account);
        initialize();
    }

    private void initialize() {
        Calendar cal = Calendar.getInstance();
        int currentYear = cal.get(Calendar.YEAR) % 100;
        //int currentMonth = cal.get(Calendar.MONTH);

        tvWelcome = findViewById(R.id.tvWelcome);
        Date currentTime = Calendar.getInstance().getTime();
        String formattedDate = DateFormat.getDateInstance().format(currentTime);
        tvWelcome.setText(formattedDate);

        tvBack = findViewById(R.id.tvBack);
        tvBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
                finish();
            }
        });


        edProfileFirstName = findViewById(R.id.edProfileFirstName);
        edProfileLastName = findViewById(R.id.edProfileLastName);
        edProfileEmail = findViewById(R.id.edProfileEmail);
        edProfilePhone = findViewById(R.id.edProfilePhone);
        edProfileCreditCard = findViewById(R.id.edProfileCreditCard);
        edCCYear = findViewById(R.id.edCCYear);
        edCCMonth = findViewById(R.id.edCCMonth);
        edCVV = findViewById(R.id.edCVV);
        btnUpdateProfile = findViewById(R.id.btnUpdateProfile);

        auth = FirebaseAuth.getInstance();
        user = auth.getCurrentUser();
        edProfileEmail.setText(user.getEmail());

        userDatabase = FirebaseDatabase
                .getInstance()
                .getReference("user");


        String email = user.getEmail();
        userDatabase.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                User userCurrent = snapshot.getValue(User.class);
                if (userCurrent.getEmail().equals(email)){
                    try {
                        if (snapshot.exists()) {
                            String fName = snapshot.child("firstName").getValue().toString();
                            edProfileFirstName.setText(fName);
                            String lName = snapshot.child("lastName").getValue().toString();
                            edProfileLastName.setText(lName);
                            String email = snapshot.child("email").getValue().toString();
                            edProfileEmail.setText(email);
                            String phone = snapshot.child("phone").getValue().toString();
                            edProfilePhone.setText(phone);
                            Map cc = (Map)snapshot.child("creditCard").getValue();
                            String number = cc.get("number").toString();
                            edProfileCreditCard.setText(number);
                            String cvv = cc.get("ccv").toString();
                            edCVV.setText(cvv);
                            int year = Integer.parseInt(cc.get("year").toString());
                            edCCYear.setText(String.valueOf(year));
                            int month = Integer.parseInt(cc.get("month").toString());
                            edCCMonth.setText(String.valueOf(month));
                        } else{
                            Toast.makeText(MyAccountActivity.this, "No data found!", Toast.LENGTH_LONG).show();
                        }
                    } catch (Exception ex) {
                        Toast.makeText(MyAccountActivity.this, ex.getMessage(), Toast.LENGTH_LONG).show();
                    }
                }
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot snapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


        btnUpdateProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                    String profileFirstName = edProfileFirstName.getText().toString().trim();
                    String profileLastName = edProfileLastName.getText().toString().trim();
                    String profileEmail = edProfileEmail.getText().toString().trim();
                    String profilePhone = edProfilePhone.getText().toString().trim();
                    String profileCreditCard = edProfileCreditCard.getText().toString().trim();
                    String ccYearStr = edCCYear.getText().toString().trim();
                    String ccMonthStr = edCCMonth.getText().toString().trim();
                    String ccCVVStr = edCVV.getText().toString().trim();
                    int profileCCYear = Integer.parseInt(ccYearStr);
                    int profileCCMonth = Integer.parseInt(ccMonthStr);
                    //int profileCVV = Integer.parseInt(ccCVVStr);

                    if (profileFirstName.isEmpty() || profileLastName.isEmpty() || profileEmail.isEmpty() || profilePhone.isEmpty() || profileCreditCard.isEmpty() || ccYearStr.isEmpty() || ccMonthStr.isEmpty() || ccCVVStr.isEmpty()) {
                        fieldsRequired = new AlertDialog.Builder(MyAccountActivity.this);
                        fieldsRequired.setTitle("Error");
                        fieldsRequired.setMessage("All fields are required.");
                        fieldsRequired.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                            }
                        });
                        fieldsRequired.setNegativeButton("Log Out", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                FirebaseAuth.getInstance().signOut();
                                Intent intent = new Intent(MyAccountActivity.this, LoginActivity.class);
                                startActivity(intent);
                                finish();
                            }
                        });
                        fieldsRequired.create().show();
                    }

                    else if(profilePhone.length() != 10 || !TextUtils.isDigitsOnly(profilePhone)){
                        verifyPhone = new AlertDialog.Builder(MyAccountActivity.this);
                        verifyPhone.setTitle("Error");
                        verifyPhone.setMessage("Invalid phone number");
                        verifyPhone.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                            }
                        });
                        verifyPhone.setNegativeButton("Log Out", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                FirebaseAuth.getInstance().signOut();
                                Intent intent = new Intent(MyAccountActivity.this, LoginActivity.class);
                                startActivity(intent);
                                finish();
                            }
                        });
                        verifyPhone.create().show();
                    }

                    else if (!isValidCreditCardNumber(profileCreditCard)) {
                        creditCardLength = new AlertDialog.Builder(MyAccountActivity.this);
                        creditCardLength.setTitle("Error");
                        creditCardLength.setMessage("Invalid credit card number");
                        creditCardLength.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                            }
                        });
                        creditCardLength.setNegativeButton("Log Out", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                FirebaseAuth.getInstance().signOut();
                                Intent intent = new Intent(MyAccountActivity.this, LoginActivity.class);
                                startActivity(intent);
                                finish();
                            }
                        });
                        creditCardLength.create().show();
                    }

                    else if (profileCCYear < currentYear) {
                        creditCardYearMonth = new AlertDialog.Builder(MyAccountActivity.this);
                        creditCardYearMonth.setTitle("Error");
                        creditCardYearMonth.setMessage("Invalid year or month");
                        creditCardYearMonth.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                            }
                        });
                        creditCardYearMonth.setNegativeButton("Log Out", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                FirebaseAuth.getInstance().signOut();
                                Intent intent = new Intent(MyAccountActivity.this, LoginActivity.class);
                                startActivity(intent);
                                finish();
                            }
                        });
                        creditCardYearMonth.create().show();
                    }


                    else if (ccCVVStr.length() != 3){
                        creditCardCVV = new AlertDialog.Builder(MyAccountActivity.this);
                        creditCardCVV.setTitle("Error");
                        creditCardCVV.setMessage("Invalid CVV");
                        creditCardCVV.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                            }
                        });
                        creditCardCVV.setNegativeButton("Log Out", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                FirebaseAuth.getInstance().signOut();
                                Intent intent = new Intent(MyAccountActivity.this, LoginActivity.class);
                                startActivity(intent);
                                finish();
                            }
                        });
                        creditCardCVV.create().show();
                    }

                    else{
                        String firstName = edProfileFirstName.getText().toString();
                        String lastName = edProfileLastName.getText().toString();
                        String currentEmail = edProfileEmail.getText().toString();
                        String phone = edProfilePhone.getText().toString();
                        String ccNumber = edProfileCreditCard.getText().toString();
                        int ccYear = Integer.parseInt(edCCYear.getText().toString());
                        int ccMonth = Integer.parseInt(edCCMonth.getText().toString());
                        String ccCVV = edCVV.getText().toString();
                        CreditCard cc = new CreditCard(ccNumber, ccYear, ccMonth, ccCVV);
                        User userCurrent = new User(firstName, lastName, currentEmail, phone, cc);

                        userDatabase.orderByChild("email").equalTo(currentEmail).addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                if (dataSnapshot.exists()) {
                                    for (DataSnapshot userSnapshot : dataSnapshot.getChildren()) {
                                        String userId = userSnapshot.getKey();
                                        userDatabase.child(userId).setValue(userCurrent);
                                    }
                                } else {
                                    String userId = userDatabase.push().getKey();
                                    userDatabase.child(userId).setValue(userCurrent);
                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {
                                // handle error
                            }
                        });

                        thankYou = new AlertDialog.Builder(MyAccountActivity.this);
                        thankYou.setTitle("Update profile");
                        thankYou.setMessage("Your profile is up to date.");
                        thankYou.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Intent intent = new Intent(MyAccountActivity.this, MainActivity.class);
                                startActivity(intent);
                                finish();
                            }
                        });
                        thankYou.create().show();
                    }
                }
                catch (Exception e){
                    Log.d("error", e.getMessage());
                }
            }
        });

        btnChangePassword = findViewById(R.id.btnChangePassword);
        btnChangePassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), ChangePassword.class);
                startActivity(intent);
                finish();
            }
        });

    }

    public static boolean isValidCreditCardNumber(String cardNumber) {
        String regex = "^(?:4[0-9]{12}(?:[0-9]{3})?|5[1-5][0-9]{14}|3[47][0-9]{13}|3(?:0[0-5]|[68][0-9])[0-9]{11}|6(?:011|5[0-9]{2})[0-9]{12}|(?:2131|1800|35\\d{3})\\d{11})$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(cardNumber);
        return matcher.matches();
    }

    @Override
    public void onClick(DialogInterface dialog, int which) {

    }

}