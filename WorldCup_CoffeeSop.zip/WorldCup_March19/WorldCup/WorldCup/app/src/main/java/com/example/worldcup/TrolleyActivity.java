package com.example.worldcup;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;

import java.text.DateFormat;
import java.util.Calendar;
import java.util.Date;

public class TrolleyActivity extends AppCompatActivity implements DialogInterface.OnClickListener, AdapterView.OnItemSelectedListener {

    TextView tvWelcome;
    private Spinner spinner;
    AlertDialog.Builder confirmLogOut;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trolley);
        initialize();
    }

    private void initialize() {
        tvWelcome = findViewById(R.id.tvWelcome);
        Date currentTime = Calendar.getInstance().getTime();
        String formattedDate = DateFormat.getDateInstance().format(currentTime);
        tvWelcome.setText("Welcome!" + "  " + formattedDate);

        resetSpinner();

        confirmLogOut = new AlertDialog.Builder(this);
        confirmLogOut.setTitle("Log Out");
        confirmLogOut.setMessage("Do you want to log out (YES/NO)");
        confirmLogOut.setPositiveButton("YES", this);
        confirmLogOut.setNegativeButton("NO", this);
    }

    private void resetSpinner() {
        spinner = findViewById(R.id.spinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.menuTrolley, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this);
    }

    @Override
    public void onClick(DialogInterface dialog, int which) {
        switch(which){
            case Dialog.BUTTON_POSITIVE:
                FirebaseAuth.getInstance().signOut();
                Intent intent = new Intent(this, LoginActivity.class);
                startActivity(intent);
                finish();
                break;
            case Dialog.BUTTON_NEGATIVE:
                resetSpinner();
                break;
        }
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int i, long id) {
        String choice = parent.getItemAtPosition(i).toString();
        Toast.makeText(getApplicationContext(), choice, Toast.LENGTH_LONG).show();

        if(choice.equalsIgnoreCase("Home"))
        {
            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(intent);
            finish();
        }
        if(choice.equalsIgnoreCase("Catalog"))
        {
            Intent intent = new Intent(getApplicationContext(), CatalogActivity.class);
            startActivity(intent);
            finish();
        }
        if(choice.equalsIgnoreCase("My Account"))
        {
            Intent intent = new Intent(getApplicationContext(), MyAccountActivity.class);
            startActivity(intent);
            finish();
        }
        if(choice.equalsIgnoreCase("Log Out"))
        {
            confirmLogOut.create().show();
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}